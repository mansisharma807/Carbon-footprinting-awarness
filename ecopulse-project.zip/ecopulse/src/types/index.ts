export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  joinDate: string;
}

export interface TransportData {
  car: number;        // km/week
  bike: number;       // km/week
  bus: number;        // km/week
  train: number;      // km/week
  flight: number;     // hours/year
}

export interface CalculatorInput {
  transport: TransportData;
  electricity: number;   // kWh/month
  foodHabit: 'vegetarian' | 'mixed' | 'nonVegetarian';
}

export interface CarbonResult {
  transport: number;
  electricity: number;
  food: number;
  total: number;
  category: 'low' | 'moderate' | 'high';
  treesNeeded: number;
  date: string;
}

export interface WeeklyData {
  day: string;
  value: number;
}

export interface MonthlyData {
  month: string;
  transport: number;
  electricity: number;
  food: number;
  total: number;
}

export interface Suggestion {
  id: string;
  category: 'transport' | 'electricity' | 'food' | 'lifestyle';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  icon: string;
  saving: number; // kg CO2/year
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  duration: string;
  co2Saving: number;
  completed: boolean;
}

export type Theme = 'light' | 'dark';
