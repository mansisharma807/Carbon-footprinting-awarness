import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, CarbonResult, Theme, Challenge } from '@/types';
import { challenges as initialChallenges } from '@/data/suggestions';

interface AppContextType {
  user: User | null;
  theme: Theme;
  history: CarbonResult[];
  challenges: Challenge[];
  setUser: (user: User | null) => void;
  toggleTheme: () => void;
  addResult: (result: CarbonResult) => void;
  toggleChallenge: (id: string) => void;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: 'ecopulse_user',
  THEME: 'ecopulse_theme',
  HISTORY: 'ecopulse_history',
  CHALLENGES: 'ecopulse_challenges',
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUserState] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.USER);
      return stored ? JSON.parse(stored) : null;
    } catch { return null; }
  });

  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return (localStorage.getItem(STORAGE_KEYS.THEME) as Theme) || 'dark';
    } catch { return 'dark'; }
  });

  const [history, setHistory] = useState<CarbonResult[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
      return stored ? JSON.parse(stored) : [];
    } catch { return []; }
  });

  const [challenges, setChallenges] = useState<Challenge[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
      return stored ? JSON.parse(stored) : initialChallenges;
    } catch { return initialChallenges; }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem(STORAGE_KEYS.THEME, theme);
  }, [theme]);

  const setUser = (u: User | null) => {
    setUserState(u);
    if (u) localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(u));
    else localStorage.removeItem(STORAGE_KEYS.USER);
  };

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');

  const addResult = (result: CarbonResult) => {
    setHistory(prev => {
      const updated = [result, ...prev].slice(0, 50);
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
      return updated;
    });
  };

  const toggleChallenge = (id: string) => {
    setChallenges(prev => {
      const updated = prev.map(c => c.id === id ? { ...c, completed: !c.completed } : c);
      localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(updated));
      return updated;
    });
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AppContext.Provider value={{
      user, theme, history, challenges,
      setUser, toggleTheme, addResult, toggleChallenge, logout,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
