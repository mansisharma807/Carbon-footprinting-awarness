import React, { ReactNode } from 'react';
import clsx from 'clsx';

interface CardProps {
  children: ReactNode;
  className?: string;
  glass?: boolean;
  onClick?: () => void;
}

export function Card({ children, className, glass, onClick }: CardProps) {
  return (
    <div
      onClick={onClick}
      className={clsx(
        'rounded-2xl border transition-all',
        glass
          ? 'bg-white/60 dark:bg-gray-800/60 backdrop-blur-xl border-gray-200/60 dark:border-gray-700/60'
          : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700',
        onClick && 'cursor-pointer hover:border-emerald-500/50',
        className
      )}
    >
      {children}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string | number;
  unit?: string;
  icon: ReactNode;
  trend?: number;
  color?: 'green' | 'yellow' | 'red' | 'blue';
}

const colorMap = {
  green: 'text-emerald-500 bg-emerald-500/10',
  yellow: 'text-yellow-500 bg-yellow-500/10',
  red: 'text-red-500 bg-red-500/10',
  blue: 'text-blue-500 bg-blue-500/10',
};

export function StatCard({ label, value, unit, icon, trend, color = 'green' }: StatCardProps) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={clsx('p-2.5 rounded-xl', colorMap[color])}>
          {icon}
        </div>
        {trend !== undefined && (
          <span className={clsx(
            'text-xs font-medium px-2 py-1 rounded-full',
            trend < 0 ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 dark:text-emerald-400' : 'text-red-600 bg-red-50 dark:bg-red-900/30 dark:text-red-400'
          )}>
            {trend < 0 ? '↓' : '↑'} {Math.abs(trend)}%
          </span>
        )}
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">
          {value}
          {unit && <span className="text-sm font-normal text-gray-500 dark:text-gray-400 ml-1">{unit}</span>}
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{label}</p>
      </div>
    </Card>
  );
}
