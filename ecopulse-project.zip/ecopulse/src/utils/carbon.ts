import { CalculatorInput, CarbonResult } from '@/types';

// Emission factors (kg CO2 per unit)
const FACTORS = {
  car: 0.21,          // kg CO2 per km
  bike: 0.0,          // electric/pedal = 0
  bus: 0.089,         // kg CO2 per km
  train: 0.041,       // kg CO2 per km
  flight: 255,        // kg CO2 per flight hour

  electricity: 0.233, // kg CO2 per kWh (India grid average)

  food: {
    vegetarian: 1.5,    // kg CO2 per day
    mixed: 2.5,         // kg CO2 per day
    nonVegetarian: 3.3, // kg CO2 per day
  }
};

// One tree absorbs ~21 kg CO2/year
const KG_PER_TREE_PER_YEAR = 21;

export function calculateCarbon(input: CalculatorInput): CarbonResult {
  // Transport (weekly → annual)
  const carEmissions = input.transport.car * FACTORS.car * 52;
  const bikeEmissions = input.transport.bike * FACTORS.bike * 52;
  const busEmissions = input.transport.bus * FACTORS.bus * 52;
  const trainEmissions = input.transport.train * FACTORS.train * 52;
  const flightEmissions = input.transport.flight * FACTORS.flight;
  const transportTotal = carEmissions + bikeEmissions + busEmissions + trainEmissions + flightEmissions;

  // Electricity (monthly → annual)
  const electricityTotal = input.electricity * FACTORS.electricity * 12;

  // Food (daily → annual)
  const foodDailyFactor = FACTORS.food[input.foodHabit];
  const foodTotal = foodDailyFactor * 365;

  const total = transportTotal + electricityTotal + foodTotal;

  let category: 'low' | 'moderate' | 'high';
  if (total < 2000) category = 'low';
  else if (total < 5000) category = 'moderate';
  else category = 'high';

  const treesNeeded = Math.ceil(total / KG_PER_TREE_PER_YEAR);

  return {
    transport: Math.round(transportTotal),
    electricity: Math.round(electricityTotal),
    food: Math.round(foodTotal),
    total: Math.round(total),
    category,
    treesNeeded,
    date: new Date().toISOString(),
  };
}

export function getCategoryColor(category: 'low' | 'moderate' | 'high'): string {
  switch (category) {
    case 'low': return 'text-emerald-500';
    case 'moderate': return 'text-yellow-500';
    case 'high': return 'text-red-500';
  }
}

export function getCategoryBg(category: 'low' | 'moderate' | 'high'): string {
  switch (category) {
    case 'low': return 'bg-emerald-500/20 border-emerald-500/40';
    case 'moderate': return 'bg-yellow-500/20 border-yellow-500/40';
    case 'high': return 'bg-red-500/20 border-red-500/40';
  }
}

export function getCategoryLabel(category: 'low' | 'moderate' | 'high'): string {
  switch (category) {
    case 'low': return '🌱 Low Impact';
    case 'moderate': return '⚡ Moderate Impact';
    case 'high': return '🔥 High Impact';
  }
}

export function generateWeeklyData() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map(day => ({
    day,
    value: Math.round(5 + Math.random() * 15),
  }));
}

export function generateMonthlyData() {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months.map(month => ({
    month,
    transport: Math.round(100 + Math.random() * 200),
    electricity: Math.round(50 + Math.random() * 100),
    food: Math.round(80 + Math.random() * 60),
    total: 0,
  })).map(d => ({ ...d, total: d.transport + d.electricity + d.food }));
}
