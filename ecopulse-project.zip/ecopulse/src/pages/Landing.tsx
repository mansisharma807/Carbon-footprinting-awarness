import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, BarChart3, Calculator, Lightbulb, TreePine, ArrowRight, Globe, Zap, Users, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: Calculator,
    title: 'Smart Calculator',
    description: 'Measure your carbon footprint across transport, electricity, and food habits with precision.',
    color: 'bg-emerald-500/10 text-emerald-500',
  },
  {
    icon: BarChart3,
    title: 'Visual Dashboard',
    description: 'Track weekly and monthly trends with beautiful interactive charts and progress indicators.',
    color: 'bg-blue-500/10 text-blue-500',
  },
  {
    icon: Lightbulb,
    title: 'AI-Style Tips',
    description: 'Receive personalized recommendations and daily eco-challenges tailored to your lifestyle.',
    color: 'bg-yellow-500/10 text-yellow-500',
  },
  {
    icon: TreePine,
    title: 'Tree Offset Tracker',
    description: 'See exactly how many trees you\'d need to plant to neutralize your annual emissions.',
    color: 'bg-teal-500/10 text-teal-500',
  },
];

const stats = [
  { value: '4.7T', label: 'Tonnes CO₂ added globally each year', icon: Globe },
  { value: '21kg', label: 'CO₂ absorbed by one tree per year', icon: TreePine },
  { value: '40%', label: 'Emissions reducible through lifestyle changes', icon: Zap },
  { value: '8B+', label: 'People who can make a difference', icon: Users },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      {/* Hero */}
      <section className="relative overflow-hidden pt-24 pb-20 sm:pt-32 sm:pb-32">
        {/* Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-emerald-500/5 blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-[400px] h-[400px] rounded-full bg-teal-500/5 blur-3xl" />
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(16,185,129,0.05) 1px, transparent 0)',
            backgroundSize: '40px 40px',
          }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-1.5 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400">Climate action starts here</span>
          </div>

          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-gray-900 dark:text-white leading-[1.05] tracking-tight mb-6">
            Know Your
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
              Carbon Pulse
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-gray-500 dark:text-gray-400 mb-10 leading-relaxed">
            EcoPulse helps you measure, understand, and reduce your personal carbon footprint — one data point at a time. Join thousands making smarter choices for the planet.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/signup"
              className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-8 py-4 rounded-2xl text-base transition-all shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:-translate-y-0.5"
            >
              Start Tracking Free
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/calculator"
              className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-900 dark:text-white font-semibold px-8 py-4 rounded-2xl text-base transition-all"
            >
              <Calculator className="w-5 h-5" />
              Try Calculator
            </Link>
          </div>

          {/* Hero visual */}
          <div className="mt-20 relative max-w-4xl mx-auto">
            <div className="rounded-3xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-2xl shadow-gray-900/10 dark:shadow-gray-900/50 overflow-hidden">
              {/* Mockup header */}
              <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-yellow-400" />
                  <div className="w-3 h-3 rounded-full bg-emerald-400" />
                </div>
                <div className="flex-1 mx-4">
                  <div className="bg-gray-200 dark:bg-gray-700 rounded-lg h-6 max-w-sm mx-auto flex items-center justify-center">
                    <span className="text-xs text-gray-400">ecopulse.app/dashboard</span>
                  </div>
                </div>
              </div>
              {/* Dashboard preview */}
              <div className="p-6 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-950">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {[
                    { label: 'Total CO₂', value: '3,240 kg', color: 'text-emerald-500' },
                    { label: 'vs Last Month', value: '↓ 12%', color: 'text-blue-500' },
                    { label: 'Trees Needed', value: '154', color: 'text-teal-500' },
                  ].map(s => (
                    <div key={s.label} className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-200 dark:border-gray-700 text-center">
                      <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label}</p>
                    </div>
                  ))}
                </div>
                {/* Fake chart */}
                <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700">
                  <div className="flex items-end gap-2 h-20">
                    {[40, 65, 45, 80, 55, 70, 48, 90, 60, 75, 50, 85].map((h, i) => (
                      <div key={i} className="flex-1 rounded-t-sm" style={{
                        height: `${h}%`,
                        background: i === 11 ? 'rgb(16,185,129)' : 'rgb(16,185,129,0.25)',
                      }} />
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-2">Monthly carbon trends</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 border-y border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map(({ value, label, icon: Icon }) => (
              <div key={label} className="text-center">
                <Icon className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                <p className="text-3xl font-black text-gray-900 dark:text-white">{value}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black text-gray-900 dark:text-white mb-4">
              Everything you need to go green
            </h2>
            <p className="text-lg text-gray-500 dark:text-gray-400 max-w-xl mx-auto">
              A complete platform built to make sustainable living measurable, trackable, and achievable.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, description, color }) => (
              <div key={title} className="bg-white dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700 rounded-2xl p-6 hover:border-emerald-500/40 hover:shadow-lg hover:shadow-emerald-500/5 transition-all group">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 ${color} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white mb-2">{title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="relative rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 p-1 shadow-2xl shadow-emerald-500/20">
            <div className="rounded-[22px] bg-gradient-to-br from-emerald-500 to-teal-600 px-8 py-16 text-center overflow-hidden">
              <div className="absolute inset-0 opacity-10" style={{
                backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)',
                backgroundSize: '32px 32px',
              }} />
              <Leaf className="w-12 h-12 text-white/80 mx-auto mb-4 animate-float" />
              <h2 className="text-4xl font-black text-white mb-4">Ready to make an impact?</h2>
              <p className="text-emerald-100 text-lg mb-8 max-w-md mx-auto">
                Join EcoPulse today and take the first step toward a lower-carbon lifestyle.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/signup"
                  className="bg-white text-emerald-700 font-bold px-8 py-3.5 rounded-xl hover:bg-emerald-50 transition-all flex items-center justify-center gap-2"
                >
                  Create Free Account
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/login"
                  className="border-2 border-white/40 text-white font-bold px-8 py-3.5 rounded-xl hover:border-white/70 hover:bg-white/10 transition-all"
                >
                  Sign in
                </Link>
              </div>
              <div className="mt-8 flex items-center justify-center gap-6 text-emerald-100 text-sm">
                {['Free forever', 'No credit card', 'Private & secure'].map(t => (
                  <div key={t} className="flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4" />
                    {t}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center">
              <Leaf className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-gray-900 dark:text-white">Eco<span className="text-emerald-500">Pulse</span></span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            © 2025 EcoPulse. Built for the planet. 🌍
          </p>
        </div>
      </footer>
    </div>
  );
}
