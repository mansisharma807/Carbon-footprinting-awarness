import React, { useState } from 'react';
import { User, Mail, Calendar, Trash2, Download, LogOut, Shield } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { useNavigate } from 'react-router-dom';
import { getCategoryColor, getCategoryLabel } from '@/utils/carbon';

export default function Profile() {
  const { user, logout, history, challenges } = useApp();
  const navigate = useNavigate();
  const [cleared, setCleared] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleClearHistory = () => {
    localStorage.removeItem('ecopulse_history');
    window.location.reload();
  };

  const handleExport = () => {
    const data = JSON.stringify(history, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ecopulse-history.json';
    a.click();
  };

  const completedChallenges = challenges.filter(c => c.completed).length;
  const latestResult = history[0];
  const totalTracked = history.reduce((s, r) => s + r.total, 0);
  const bestScore = history.length ? Math.min(...history.map(r => r.total)) : 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900 dark:text-white">Your Profile</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Manage your account and data</p>
        </div>

        {/* User card */}
        <Card className="p-6 mb-6">
          <div className="flex items-start gap-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white text-2xl font-black flex-shrink-0">
              {user?.name?.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{user?.name}</h2>
              <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mt-1">
                <Mail className="w-3.5 h-3.5" />
                {user?.email}
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                <Calendar className="w-3.5 h-3.5" />
                Joined {user?.joinDate ? new Date(user.joinDate).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'recently'}
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 px-3 py-1.5 rounded-full text-sm font-medium">
              <Shield className="w-3.5 h-3.5" />
              Eco Member
            </div>
          </div>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Calculations', value: history.length, icon: '📊' },
            { label: 'Challenges Done', value: completedChallenges, icon: '✅' },
            { label: 'Best Score', value: bestScore ? `${bestScore.toLocaleString()}` : '—', icon: '🏆' },
            { label: 'Total Tracked', value: totalTracked ? `${(totalTracked / 1000).toFixed(1)}t` : '—', icon: '🌍' },
          ].map(s => (
            <Card key={s.label} className="p-4 text-center">
              <div className="text-2xl mb-1">{s.icon}</div>
              <p className="font-bold text-gray-900 dark:text-white">{s.value}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label}</p>
            </Card>
          ))}
        </div>

        {/* Latest result */}
        {latestResult && (
          <Card className="p-6 mb-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4">Latest Footprint Summary</h3>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className={`text-3xl font-black ${getCategoryColor(latestResult.category)}`}>
                  {latestResult.total.toLocaleString()} kg
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{getCategoryLabel(latestResult.category)}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl">🌳</p>
                <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{latestResult.treesNeeded}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">trees to offset</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Transport', value: latestResult.transport },
                { label: 'Electricity', value: latestResult.electricity },
                { label: 'Food', value: latestResult.food },
              ].map(s => (
                <div key={s.label} className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-3 text-center">
                  <p className="font-semibold text-gray-900 dark:text-white">{s.value.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label} kg</p>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Actions */}
        <Card className="p-6">
          <h3 className="font-bold text-gray-900 dark:text-white mb-4">Account Actions</h3>
          <div className="space-y-3">
            <button
              onClick={handleExport}
              disabled={history.length === 0}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-blue-400 hover:text-blue-600 dark:hover:text-blue-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
            >
              <Download className="w-4 h-4" />
              Export History as JSON
              {history.length === 0 && <span className="ml-auto text-xs text-gray-400">No data yet</span>}
            </button>

            <button
              onClick={handleClearHistory}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-red-400 hover:text-red-600 dark:hover:text-red-400 transition-all text-sm font-medium"
            >
              <Trash2 className="w-4 h-4" />
              Clear All History
            </button>

            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-red-200 dark:border-red-900/50 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all text-sm font-medium"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
