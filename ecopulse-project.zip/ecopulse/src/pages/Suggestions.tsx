import React, { useState } from 'react';
import { Lightbulb, CheckCircle, Circle, Filter } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { suggestions } from '@/data/suggestions';
import { Suggestion } from '@/types';
import clsx from 'clsx';

type Category = 'all' | 'transport' | 'electricity' | 'food' | 'lifestyle';

const impactColor = {
  high: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400',
  medium: 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400',
  low: 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400',
};

const categoryLabels: Record<Category, string> = {
  all: 'All Tips',
  transport: '🚌 Transport',
  electricity: '⚡ Electricity',
  food: '🥗 Food',
  lifestyle: '🌿 Lifestyle',
};

function SuggestionCard({ suggestion }: { suggestion: Suggestion }) {
  return (
    <Card className="p-5 hover:border-emerald-500/30 hover:shadow-md transition-all group">
      <div className="flex items-start gap-4">
        <div className="text-3xl flex-shrink-0">{suggestion.icon}</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-semibold text-gray-900 dark:text-white text-sm leading-tight">{suggestion.title}</h3>
            <span className={clsx('text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0', impactColor[suggestion.impact])}>
              {suggestion.impact} impact
            </span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mb-3">{suggestion.description}</p>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 px-3 py-1 rounded-full text-xs font-medium">
              💨 Saves ~{suggestion.saving.toLocaleString()} kg CO₂/year
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function ChallengeCard() {
  const { challenges, toggleChallenge } = useApp();
  const completed = challenges.filter(c => c.completed).length;
  const totalSaved = challenges.filter(c => c.completed).reduce((s, c) => s + c.co2Saving, 0);

  return (
    <div className="space-y-4">
      {/* Progress */}
      <Card className="p-5 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border-emerald-200 dark:border-emerald-800">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="font-bold text-gray-900 dark:text-white">Daily Challenges</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">{completed}/{challenges.length} completed</p>
          </div>
          <div className="text-right">
            <p className="text-xl font-black text-emerald-600 dark:text-emerald-400">{totalSaved.toFixed(1)}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">kg CO₂ saved</p>
          </div>
        </div>
        <div className="h-2 bg-emerald-100 dark:bg-emerald-900/40 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-500 rounded-full transition-all"
            style={{ width: `${(completed / challenges.length) * 100}%` }}
          />
        </div>
      </Card>

      {challenges.map(c => (
        <div
          key={c.id}
          onClick={() => toggleChallenge(c.id)}
          className={clsx(
            'flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all',
            c.completed
              ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800'
              : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-emerald-400'
          )}
        >
          {c.completed
            ? <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
            : <Circle className="w-5 h-5 text-gray-300 dark:text-gray-600 flex-shrink-0 mt-0.5" />
          }
          <div className="flex-1">
            <p className={clsx('font-medium text-sm', c.completed ? 'line-through text-gray-400' : 'text-gray-900 dark:text-white')}>
              {c.title}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{c.description}</p>
            <div className="flex items-center gap-3 mt-2">
              <span className="text-xs text-gray-400">⏱ {c.duration}</span>
              <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">💨 {c.co2Saving} kg CO₂</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Suggestions() {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [activeTab, setActiveTab] = useState<'tips' | 'challenges'>('tips');

  const filtered = activeCategory === 'all' ? suggestions : suggestions.filter(s => s.category === activeCategory);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900 dark:text-white flex items-center gap-3">
            <Lightbulb className="w-8 h-8 text-yellow-500" />
            Eco Tips & Challenges
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Personalized recommendations to lower your carbon footprint</p>
        </div>

        {/* Tab */}
        <div className="flex gap-2 mb-6">
          {(['tips', 'challenges'] as const).map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={clsx(
                'px-5 py-2 rounded-xl text-sm font-medium transition-all capitalize',
                activeTab === t
                  ? 'bg-emerald-500 text-white shadow-sm'
                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-gray-700 hover:border-emerald-400'
              )}
            >
              {t === 'tips' ? '💡 Tips & Recommendations' : '🎯 Daily Challenges'}
            </button>
          ))}
        </div>

        {activeTab === 'tips' ? (
          <>
            {/* Category filter */}
            <div className="flex items-center gap-2 mb-6 flex-wrap">
              <Filter className="w-4 h-4 text-gray-400 flex-shrink-0" />
              {(Object.keys(categoryLabels) as Category[]).map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={clsx(
                    'px-3 py-1.5 rounded-lg text-xs font-medium transition-all',
                    activeCategory === cat
                      ? 'bg-emerald-500 text-white'
                      : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border border-gray-200 dark:border-gray-700 hover:border-emerald-400'
                  )}
                >
                  {categoryLabels[cat]}
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {filtered.map(s => <SuggestionCard key={s.id} suggestion={s} />)}
            </div>

            {/* Potential savings */}
            <Card className="mt-6 p-5 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border-emerald-200 dark:border-emerald-800">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">If you followed all tips...</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">You could save up to</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-black text-emerald-600 dark:text-emerald-400">
                    {suggestions.reduce((s, t) => s + t.saving, 0).toLocaleString()}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">kg CO₂ per year</p>
                </div>
              </div>
            </Card>
          </>
        ) : (
          <ChallengeCard />
        )}
      </div>
    </div>
  );
}
