import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, TrendingDown, Leaf, TreePine, Calculator, Calendar, Zap } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Card, StatCard } from '@/components/ui/Card';
import { getCategoryColor, getCategoryLabel, generateWeeklyData, generateMonthlyData } from '@/utils/carbon';
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, Legend,
} from 'recharts';

const weeklyData = generateWeeklyData();
const monthlyData = generateMonthlyData();

export default function Dashboard() {
  const { user, history } = useApp();
  const latest = history[0] ?? null;

  const totalSaved = useMemo(() => {
    if (history.length < 2) return 0;
    return history[1].total - history[0].total;
  }, [history]);

  const avgFootprint = useMemo(() => {
    if (history.length === 0) return 0;
    return Math.round(history.reduce((s, r) => s + r.total, 0) / history.length);
  }, [history]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black text-gray-900 dark:text-white">
              Hello, {user?.name?.split(' ')[0]} 👋
            </h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">Here's your environmental impact overview</p>
          </div>
          <Link to="/calculator">
            <button className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-5 py-2.5 rounded-xl transition-all text-sm">
              <Calculator className="w-4 h-4" />
              New Calculation
            </button>
          </Link>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard
            label="Total Footprint"
            value={latest ? latest.total.toLocaleString() : '—'}
            unit={latest ? 'kg CO₂' : ''}
            icon={<BarChart3 className="w-5 h-5 text-emerald-500" />}
            color="green"
          />
          <StatCard
            label="Change vs Previous"
            value={totalSaved ? (totalSaved > 0 ? `+${totalSaved}` : totalSaved) : '—'}
            unit={totalSaved ? 'kg' : ''}
            icon={<TrendingDown className="w-5 h-5 text-blue-500" />}
            trend={totalSaved && avgFootprint ? Math.round((totalSaved / avgFootprint) * 100) : undefined}
            color="blue"
          />
          <StatCard
            label="Trees to Offset"
            value={latest ? latest.treesNeeded : '—'}
            icon={<TreePine className="w-5 h-5 text-teal-500" />}
            color="green"
          />
          <StatCard
            label="Calculations Saved"
            value={history.length}
            icon={<Calendar className="w-5 h-5 text-yellow-500" />}
            color="yellow"
          />
        </div>

        {/* Current score */}
        {latest && (
          <Card className="p-6 mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center gap-6">
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Latest Carbon Score</p>
                <div className="flex items-baseline gap-3">
                  <span className={`text-5xl font-black ${getCategoryColor(latest.category)}`}>
                    {latest.total.toLocaleString()}
                  </span>
                  <span className="text-gray-500 dark:text-gray-400">kg CO₂/year</span>
                </div>
                <div className="mt-2">
                  <span className={`text-sm font-semibold ${getCategoryColor(latest.category)}`}>
                    {getCategoryLabel(latest.category)}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 sm:border-l sm:border-gray-200 sm:dark:border-gray-700 sm:pl-6">
                {[
                  { label: 'Transport', value: latest.transport, icon: '🚗' },
                  { label: 'Electricity', value: latest.electricity, icon: '⚡' },
                  { label: 'Food', value: latest.food, icon: '🍽️' },
                ].map(s => (
                  <div key={s.label} className="text-center">
                    <p className="text-2xl mb-1">{s.icon}</p>
                    <p className="font-bold text-gray-900 dark:text-white text-sm">{s.value.toLocaleString()}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{s.label} kg</p>
                  </div>
                ))}
              </div>
            </div>
            {/* Progress bar */}
            <div className="mt-4">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>0 kg (Net Zero)</span>
                <span>10,000 kg (World avg)</span>
              </div>
              <div className="h-3 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    latest.category === 'low' ? 'bg-emerald-500' :
                    latest.category === 'moderate' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${Math.min((latest.total / 10000) * 100, 100)}%` }}
                />
              </div>
            </div>
          </Card>
        )}

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Weekly */}
          <Card className="p-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-500" />
              Weekly Emissions
              <span className="text-xs font-normal text-gray-500 ml-auto">kg CO₂/day</span>
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="greenGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" opacity={0.3} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '12px', color: '#f9fafb' }}
                  formatter={(v: number) => [`${v} kg`, 'CO₂']}
                />
                <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2.5} fill="url(#greenGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          {/* Monthly */}
          <Card className="p-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-500" />
              Monthly Breakdown
              <span className="text-xs font-normal text-gray-500 ml-auto">kg CO₂/month</span>
            </h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={monthlyData} barSize={6}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" opacity={0.3} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '12px', color: '#f9fafb' }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="transport" name="Transport" fill="#3b82f6" radius={[2, 2, 0, 0]} />
                <Bar dataKey="electricity" name="Electricity" fill="#f59e0b" radius={[2, 2, 0, 0]} />
                <Bar dataKey="food" name="Food" fill="#10b981" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* History */}
        {history.length > 0 && (
          <Card className="p-6">
            <h3 className="font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-500" />
              Calculation History
            </h3>
            <div className="space-y-2">
              {history.slice(0, 5).map((r, i) => (
                <div key={i} className="flex items-center justify-between py-3 border-b border-gray-100 dark:border-gray-700 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${r.category === 'low' ? 'bg-emerald-500' : r.category === 'moderate' ? 'bg-yellow-500' : 'bg-red-500'}`} />
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{r.total.toLocaleString()} kg CO₂</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(r.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                    <span className="hidden sm:block">🚗 {r.transport} · ⚡ {r.electricity} · 🍽️ {r.food}</span>
                    <span className={`px-2 py-1 rounded-full font-medium ${
                      r.category === 'low' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' :
                      r.category === 'moderate' ? 'bg-yellow-50 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400' :
                      'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                    }`}>
                      {r.category}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Empty state */}
        {history.length === 0 && (
          <Card className="p-12 text-center">
            <Leaf className="w-12 h-12 text-emerald-500/40 mx-auto mb-4" />
            <h3 className="font-bold text-gray-900 dark:text-white mb-2">No data yet</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Use the calculator to measure your first carbon footprint and start tracking your progress.
            </p>
            <Link to="/calculator">
              <button className="bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-6 py-2.5 rounded-xl transition-all text-sm">
                Go to Calculator
              </button>
            </Link>
          </Card>
        )}
      </div>
    </div>
  );
}
