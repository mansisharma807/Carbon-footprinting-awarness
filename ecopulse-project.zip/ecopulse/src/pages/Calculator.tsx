import React, { useState } from 'react';
import { Car, Bike, Bus, Train, Plane, Zap, Utensils, ArrowRight, RotateCcw, TreePine } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { CalculatorInput, CarbonResult } from '@/types';
import { calculateCarbon, getCategoryColor, getCategoryBg, getCategoryLabel } from '@/utils/carbon';
import { Card } from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const defaultInput: CalculatorInput = {
  transport: { car: 50, bike: 0, bus: 20, train: 10, flight: 2 },
  electricity: 200,
  foodHabit: 'mixed',
};

const COLORS = ['#10b981', '#3b82f6', '#f59e0b'];

function SliderInput({ label, value, onChange, min, max, step, unit, icon }: {
  label: string; value: number; onChange: (v: number) => void;
  min: number; max: number; step: number; unit: string; icon: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
          {icon}
          {label}
        </div>
        <div className="flex items-center gap-1">
          <input
            type="number"
            value={value}
            onChange={e => onChange(Number(e.target.value))}
            min={min}
            max={max}
            step={step}
            className="w-20 text-right rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 px-2 py-1 text-sm text-gray-900 dark:text-white outline-none focus:border-emerald-500"
          />
          <span className="text-xs text-gray-500 dark:text-gray-400 w-12">{unit}</span>
        </div>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-2 appearance-none rounded-full bg-gray-200 dark:bg-gray-700 accent-emerald-500 cursor-pointer"
      />
      <div className="flex justify-between text-xs text-gray-400">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

export default function Calculator() {
  const { addResult } = useApp();
  const [input, setInput] = useState<CalculatorInput>(defaultInput);
  const [result, setResult] = useState<CarbonResult | null>(null);
  const [saved, setSaved] = useState(false);

  const updateTransport = (key: keyof CalculatorInput['transport'], val: number) => {
    setInput(p => ({ ...p, transport: { ...p.transport, [key]: val } }));
    setResult(null);
    setSaved(false);
  };

  const handleCalculate = () => {
    const r = calculateCarbon(input);
    setResult(r);
    setSaved(false);
  };

  const handleSave = () => {
    if (result) {
      addResult(result);
      setSaved(true);
    }
  };

  const handleReset = () => {
    setInput(defaultInput);
    setResult(null);
    setSaved(false);
  };

  const chartData = result ? [
    { name: 'Transport', value: result.transport },
    { name: 'Electricity', value: result.electricity },
    { name: 'Food', value: result.food },
  ] : [];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-black text-gray-900 dark:text-white">Carbon Calculator</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Enter your habits to calculate your annual carbon footprint</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left: Input */}
          <div className="space-y-6">
            {/* Transport */}
            <Card className="p-6">
              <h2 className="font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Car className="w-4 h-4 text-blue-500" />
                </div>
                Transportation
                <span className="text-xs font-normal text-gray-500 ml-auto">per week</span>
              </h2>
              <div className="space-y-5">
                <SliderInput label="Car" value={input.transport.car} onChange={v => updateTransport('car', v)} min={0} max={500} step={5} unit="km/wk" icon={<Car className="w-4 h-4 text-gray-500" />} />
                <SliderInput label="Bicycle" value={input.transport.bike} onChange={v => updateTransport('bike', v)} min={0} max={100} step={1} unit="km/wk" icon={<Bike className="w-4 h-4 text-emerald-500" />} />
                <SliderInput label="Bus" value={input.transport.bus} onChange={v => updateTransport('bus', v)} min={0} max={300} step={5} unit="km/wk" icon={<Bus className="w-4 h-4 text-gray-500" />} />
                <SliderInput label="Train" value={input.transport.train} onChange={v => updateTransport('train', v)} min={0} max={500} step={10} unit="km/wk" icon={<Train className="w-4 h-4 text-gray-500" />} />
                <SliderInput label="Flights" value={input.transport.flight} onChange={v => updateTransport('flight', v)} min={0} max={100} step={1} unit="hrs/yr" icon={<Plane className="w-4 h-4 text-gray-500" />} />
              </div>
            </Card>

            {/* Electricity */}
            <Card className="p-6">
              <h2 className="font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                <div className="w-8 h-8 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-yellow-500" />
                </div>
                Electricity Usage
                <span className="text-xs font-normal text-gray-500 ml-auto">per month</span>
              </h2>
              <SliderInput label="Consumption" value={input.electricity} onChange={v => setInput(p => ({ ...p, electricity: v }))} min={0} max={2000} step={10} unit="kWh/mo" icon={<Zap className="w-4 h-4 text-yellow-500" />} />
            </Card>

            {/* Food */}
            <Card className="p-6">
              <h2 className="font-bold text-gray-900 dark:text-white flex items-center gap-2 mb-5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Utensils className="w-4 h-4 text-emerald-500" />
                </div>
                Food Habits
              </h2>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: 'vegetarian', label: '🥗 Vegetarian', desc: '1.5 kg CO₂/day' },
                  { value: 'mixed', label: '🍽️ Mixed', desc: '2.5 kg CO₂/day' },
                  { value: 'nonVegetarian', label: '🥩 Non-Veg', desc: '3.3 kg CO₂/day' },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setInput(p => ({ ...p, foodHabit: opt.value as CalculatorInput['foodHabit'] }))}
                    className={`p-3 rounded-xl border-2 text-center transition-all ${
                      input.foodHabit === opt.value
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    <div className="text-lg mb-1">{opt.label.split(' ')[0]}</div>
                    <div className="text-xs font-medium text-gray-900 dark:text-white">{opt.label.split(' ').slice(1).join(' ')}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{opt.desc}</div>
                  </button>
                ))}
              </div>
            </Card>

            <div className="flex gap-3">
              <Button onClick={handleCalculate} size="lg" className="flex-1">
                Calculate Footprint
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button onClick={handleReset} variant="secondary" size="lg">
                <RotateCcw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Right: Result */}
          <div className="space-y-6">
            {result ? (
              <>
                {/* Score card */}
                <Card className={`p-6 border-2 ${getCategoryBg(result.category)}`}>
                  <div className="text-center">
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Annual Carbon Footprint</p>
                    <p className={`text-6xl font-black mb-1 ${getCategoryColor(result.category)}`}>
                      {result.total.toLocaleString()}
                    </p>
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-3">kg CO₂ per year</p>
                    <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-semibold border ${getCategoryBg(result.category)} ${getCategoryColor(result.category)}`}>
                      {getCategoryLabel(result.category)}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 mt-6">
                    {[
                      { label: 'Transport', value: result.transport, color: 'text-blue-500' },
                      { label: 'Electricity', value: result.electricity, color: 'text-yellow-500' },
                      { label: 'Food', value: result.food, color: 'text-emerald-500' },
                    ].map(s => (
                      <div key={s.label} className="bg-white/60 dark:bg-black/20 rounded-xl p-3 text-center">
                        <p className={`font-bold ${s.color}`}>{s.value.toLocaleString()}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label} kg</p>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Chart */}
                <Card className="p-6">
                  <h3 className="font-bold text-gray-900 dark:text-white mb-4">Emissions Breakdown</h3>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={chartData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                        {chartData.map((_, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(v: number) => [`${v.toLocaleString()} kg CO₂`, '']} />
                    </PieChart>
                  </ResponsiveContainer>
                </Card>

                {/* Trees needed */}
                <Card className="p-6 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border-emerald-200 dark:border-emerald-800">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                      <TreePine className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 dark:text-white mb-1">Trees Needed to Offset</h3>
                      <p className="text-4xl font-black text-emerald-600 dark:text-emerald-400">{result.treesNeeded}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        trees planted and grown for 1 year would neutralize your {result.total.toLocaleString()} kg CO₂ footprint.
                        <br />
                        <span className="text-xs text-gray-500 mt-1 block">(Each tree absorbs ~21 kg CO₂/year)</span>
                      </p>
                    </div>
                  </div>
                </Card>

                <Button
                  onClick={handleSave}
                  variant={saved ? 'secondary' : 'primary'}
                  size="lg"
                  className="w-full"
                  disabled={saved}
                >
                  {saved ? '✓ Saved to History' : 'Save to Dashboard'}
                </Button>
              </>
            ) : (
              <Card className="p-12 text-center">
                <div className="w-20 h-20 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-10 h-10 text-emerald-500" />
                </div>
                <h3 className="font-bold text-gray-900 dark:text-white mb-2">Ready to calculate</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Fill in your habits on the left and click "Calculate Footprint" to see your results.
                </p>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
