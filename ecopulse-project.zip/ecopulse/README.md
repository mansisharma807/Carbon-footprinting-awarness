# 🌿 EcoPulse — Carbon Footprint Awareness Platform

A modern, full-featured carbon footprint tracking platform built with React, TypeScript, and Tailwind CSS.

## Features
- 🧮 **Carbon Calculator** — Transport, electricity, and food habit inputs
- 📊 **Interactive Dashboard** — Weekly/monthly trends with Recharts
- 💡 **Personalized Tips** — AI-style recommendations and challenges
- 🌳 **Tree Offset Tracker** — See how many trees offset your footprint
- 🔒 **User Accounts** — Login/signup with localStorage persistence
- 🌙 **Dark/Light Mode** — System-aware theme toggle
- 📱 **Fully Responsive** — Mobile-first design

## Quick Start

```bash
npm install
npm run dev
```

## Build for Production

```bash
npm run build
npm run preview
```

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

## Tech Stack
- **React 18** + **TypeScript**
- **Tailwind CSS** for styling
- **Recharts** for data visualization
- **React Router v6** for navigation
- **Vite** for bundling

## Carbon Emission Factors
- Car: 0.21 kg CO₂/km
- Bus: 0.089 kg CO₂/km
- Train: 0.041 kg CO₂/km
- Flight: 255 kg CO₂/hour
- Electricity: 0.233 kg CO₂/kWh (India grid average)
- Vegetarian diet: 1.5 kg CO₂/day
- Mixed diet: 2.5 kg CO₂/day
- Non-vegetarian diet: 3.3 kg CO₂/day

## Score Categories
- 🌱 **Low Impact**: < 2,000 kg CO₂/year
- ⚡ **Moderate Impact**: 2,000–5,000 kg CO₂/year  
- 🔥 **High Impact**: > 5,000 kg CO₂/year

## License
MIT
